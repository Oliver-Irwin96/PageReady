/* GET /api/health — verifies PayPal + Printful credentials without touching money.
   Safe to leave deployed; returns no secrets. */
const { PF_BASE, pfHeaders, paypalToken, json } = require('./_lib');

exports.handler = async () => {
  const out = { paypal: 'unconfigured', printful: 'unconfigured', env: process.env.PAYPAL_ENV || 'sandbox' };

  try {
    await paypalToken();
    out.paypal = 'OK';
  } catch (e) { out.paypal = `FAIL: ${e.message}`; }

  try {
    const res = await fetch(`${PF_BASE}/store`, { headers: pfHeaders() });
    const data = await res.json();
    out.printful = res.ok ? `OK — store: ${data?.result?.name || 'unnamed'} (type: ${data?.result?.type || '?'})` : `FAIL: ${res.status} ${JSON.stringify(data?.error || data).slice(0, 200)}`;
  } catch (e) { out.printful = `FAIL: ${e.message}`; }

  return json(200, out);
};
